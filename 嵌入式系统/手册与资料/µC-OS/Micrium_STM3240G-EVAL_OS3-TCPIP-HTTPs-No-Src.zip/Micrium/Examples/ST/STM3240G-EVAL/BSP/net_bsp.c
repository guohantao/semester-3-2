/*
*********************************************************************************************************
*                                             uC/TCP-IP
*                                      The Embedded TCP/IP Suite
*
*                         (c) Copyright 2004-2015; Micrium, Inc.; Weston, FL
*
*                  All rights reserved.  Protected by international copyright laws.
*
*                  uC/TCP-IP is provided in source form to registered licensees ONLY.  It is
*                  illegal to distribute this source code to any third party unless you receive
*                  written permission by an authorized Micrium representative.  Knowledge of
*                  the source code may NOT be used to develop a similar product.
*
*                  Please help us continue to provide the Embedded community with the finest
*                  software available.  Your honesty is greatly appreciated.
*
*                  You can find our product's user manual, API reference, release notes and
*                  more information at: https://doc.micrium.com
*
*                  You can contact us at: http://www.micrium.com
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*
*                            NETWORK BOARD SUPPORT PACKAGE (BSP) FUNCTIONS
*
*                                     ST Microelectronics STM32
*                                              on the
*
*                                           STM3240G-EVAL
*                                         Evaluation Board
*
* Filename      : net_bsp.c
* Version       : V3.03.00
* Programmer(s) : ITJ
*                 DC
*********************************************************************************************************
* Note(s)       : (1) To provide the required Board Support Package functionality, insert the appropriate
*                     board-specific code to perform the stated actions wherever 'TODO' comments are found.
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                            INCLUDE FILES
*********************************************************************************************************
*/

#define    NET_BSP_MODULE
#include  <IF/net_if_ether.h>
#include  <bsp.h>
#include  <net_bsp.h>
#include  <stm32f4xx_hal.h>

#ifdef  NET_IF_ETHER_MODULE_EN

/*
*********************************************************************************************************
*                                            LOCAL DEFINES
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                           LOCAL CONSTANTS
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                          LOCAL DATA TYPES
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                       LOCAL GLOBAL VARIABLES
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*                                  NETWORK DEVICE INTERFACE NUMBERS
*
* Note(s) : (1) (a) Each network device maps to a unique network interface number.
*
*               (b) Instances of network devices' interface number SHOULD be named using the following
*                   convention :
*
*                       <Board><Device>[Number]_IF_Nbr
*
*                           where
*                                   <Board>         Development board name
*                                   <Device>        Network device name (or type)
*                                   [Number]        Network device number for each specific instance
*                                                       of device (optional if the development board
*                                                       does NOT support multiple instances of the
*                                                       specific device)
*
*                   For example, the network device interface number variable for the #2 MACB Ethernet
*                   controller on an Atmel AT91SAM92xx should be named 'AT91SAM92xx_MACB_2_IF_Nbr'.
*
*               (c) Network device interface number variables SHOULD be initialized to 'NET_IF_NBR_NONE'.
*********************************************************************************************************
*/

#ifdef  NET_IF_ETHER_MODULE_EN
static  NET_IF_NBR  STM32F4xx_IF_Nbr = NET_IF_NBR_NONE;
#endif


/*
*********************************************************************************************************
*                                      LOCAL FUNCTION PROTOTYPES
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*                               NETWORK DEVICE BSP FUNCTION PROTOTYPES
*
* Note(s) : (1) Device driver BSP functions may be arbitrarily named.  However, it is recommended that
*               device BSP functions be named using the suggested names/conventions provided below.
*
*               (a) (1) Network device BSP functions SHOULD be named using the following convention :
*
*                           NetDev_[Device]<Function>[Number]()
*
*                               where
*                                   (A) [Device]        Network device name or type (optional if the
*                                                           development board does NOT support multiple
*                                                           devices)
*                                   (B) <Function>      Network device BSP function
*                                   (C) [Number]        Network device number for each specific instance
*                                                           of device (optional if the development board
*                                                           does NOT support multiple instances of the
*                                                           specific device)
*
*                       For example, the NetDev_CfgClk() function for the #2 MACB Ethernet controller
*                       on an Atmel AT91SAM92xx should be named NetDev_MACB_CfgClk2().
*
*                   (2) BSP-level device ISR handlers SHOULD be named using the following convention :
*
*                           NetDev_[Device]ISR_Handler[Type][Number]()
*
*                               where
*                                   (A) [Device]        Network device name or type (optional if the
*                                                           development board does NOT support multiple
*                                                           devices)
*                                   (B) [Type]          Network device interrupt type (optional if
*                                                           interrupt type is generic or unknown)
*                                   (C) [Number]        Network device number for each specific instance
*                                                           of device (optional if the development board
*                                                           does NOT support multiple instances of the
*                                                           specific device)
*
*               (b) All BSP function prototypes SHOULD be located within the development board's network
*                   BSP C source file ('net_bsp.c') & be declared as static functions to prevent name
*                   clashes with other network protocol suite BSP functions/files.
*********************************************************************************************************
*/

static  void        NetDev_CfgClk              (NET_IF   *p_if,
                                                NET_ERR  *p_err);

static  void        NetDev_CfgIntCtrl          (NET_IF   *p_if,
                                                NET_ERR  *p_err);

static  void        NetDev_CfgGPIO             (NET_IF   *p_if,
                                                NET_ERR  *p_err);

static  CPU_INT32U  NetDev_ClkFreqGet          (NET_IF   *p_if,
                                                NET_ERR  *p_err);


static  void        NetBSP_ISR_HandlerSTM32F4xx(void);


/*
*********************************************************************************************************
*                                            LOCAL TABLES
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*                                    NETWORK DEVICE BSP INTERFACE
*
* Note(s) : (1) Device board-support package (BSP) interface structures are used by the device driver to
*               call specific devices' BSP functions via function pointer instead of by name.  This enables
*               the network protocol suite to compile & operate with multiple instances of multiple devices
*               & drivers.
*
*           (2) In most cases, the BSP interface structure provided below SHOULD suffice for most devices'
*               BSP functions exactly as is with the exception that BSP interface structures' names MUST be
*               unique & SHOULD clearly identify the development board, device name, & possibly the specific
*               device number (if the development board supports multiple instances of any given device).
*
*               (a) BSP interface structures SHOULD be named using the following convention :
*
*                       NetDev_BSP_<Board><Device>[Number]{}
*
*                           where
*                               (1) <Board>         Development board name
*                               (2) <Device>        Network device name (or type)
*                               (3) [Number]        Network device number for each specific instance
*                                                       of device (optional if the development board
*                                                       does NOT support multiple instances of the
*                                                       specific device)
*
*                   For example, the BSP interface structure for the #2 MACB Ethernet controller on
*                   an Atmel AT91SAM92xx should be named NetDev_BSP_AT91SAM92xx_MACB_2{}.
*
*               (b) The BSP interface structure MUST also be externally declared in the development
*                   board's network BSP header file ('net_bsp.h') with the exact same name & type.
*********************************************************************************************************
*/

const  NET_DEV_BSP_ETHER  NetDev_BSP_STM32F4xx = {                       /* Board-/device-specific BSP fnct ptrs :      */
                                                   &NetDev_CfgClk,       /*   Cfg clk(s)                                */
                                                   &NetDev_CfgIntCtrl,   /*   Cfg int ctrl(s)                           */
                                                   &NetDev_CfgGPIO,      /*   Cfg GPIO                                  */
                                                   &NetDev_ClkFreqGet    /*   Get clk freq                              */
                                                 };

/*
*********************************************************************************************************
*                                     LOCAL CONFIGURATION ERRORS
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*********************************************************************************************************
*                              NETWORK ETHERNET DEVICE DRIVER FUNCTIONS
*********************************************************************************************************
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*                                           NetDev_CfgClk()
*
* Description : Configure clocks for the specified interface/device.
*
* Argument(s) : p_if         Pointer to network interface to configure.
*               ----         Argument validated in NetIF_Add().
*
*               p_err        Pointer to variable that will receive the return error code from this function :
*
*                               NET_DEV_ERR_NONE                Device clock(s)     successfully configured.
*                               NET_DEV_ERR_FAULT               Device clock(s) NOT successfully configured.
*
* Return(s)   : none.
*
* Caller(s)   : NetDev_Init().
*
* Note(s)     : (1) The external Ethernet Phy may be clocked using several different sources.  The
*                   resulting Phy clock MUST be 25MHz for MII and 50MHz for RMII :
*
*                   (a) RCC_MCO_NoClock    External Phy clocked directly via external crystal.
*                   (b) RCC_MCO_XT1        External Phy clocked by HSE   via MCO output.
*                   (c) RCC_MCO_PLL3CLK    External Phy clocked by PLL3  via MCO output.
*********************************************************************************************************
*/

static  void  NetDev_CfgClk (NET_IF   *p_if,
                             NET_ERR  *p_err)
{
    NET_PHY_CFG_ETHER  *p_phy_cfg;


    p_phy_cfg = p_if->Ext_Cfg;                                  /* Obtain pointer to Phy cfg.                           */
    if (p_phy_cfg == (NET_PHY_CFG_ETHER *)0u) {
       *p_err = NET_DEV_ERR_INVALID_CFG;
        return;
    }

    __HAL_RCC_ETHMAC_FORCE_RESET();
    __HAL_RCC_ETHMAC_RELEASE_RESET();

    __HAL_RCC_ETHMAC_CLK_ENABLE();
    __HAL_RCC_ETHMACTX_CLK_ENABLE();
    __HAL_RCC_ETHMACRX_CLK_ENABLE();

    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();
    __HAL_RCC_GPIOC_CLK_ENABLE();
    __HAL_RCC_GPIOF_CLK_ENABLE();
    __HAL_RCC_GPIOG_CLK_ENABLE();
    __HAL_RCC_GPIOH_CLK_ENABLE();
    __HAL_RCC_GPIOI_CLK_ENABLE();

    SYSCFG->PMC &= ~(SYSCFG_PMC_MII_RMII_SEL);

    if (p_phy_cfg->BusMode == NET_PHY_BUS_MODE_MII) {           /* See Note #2.                                         */
                                                                /* Output HSE clk(25MHz) on MCO pin(PA8) to clk the PHY */
        HAL_RCC_MCOConfig(RCC_MCO1,
                          RCC_MCO1SOURCE_HSE,
                          RCC_MCODIV_1);

        SYSCFG->PMC |= ETH_MEDIA_INTERFACE_MII;                 /* Select Ethernet Media Interface.                     */
    } else {
        HAL_RCC_MCOConfig(RCC_MCO1,
                          RCC_MCO1SOURCE_PLLCLK,
                          RCC_MCODIV_2);

        SYSCFG->PMC |= ETH_MEDIA_INTERFACE_RMII;                /* Select Ethernet Media Interface.                     */
    }

   *p_err = NET_DEV_ERR_NONE;
}


/*
*********************************************************************************************************
*                                         NetDev_CfgIntCtrl()
*
* Description : Configure interrupts &/or interrupt controller for the specified interface/device.
*
* Argument(s) : p_if         Pointer to network interface to configure.
*               ----         Argument validated in NetIF_Add().
*
*               p_err        Pointer to variable that will receive the return error code from this function :
*
*                               NET_DEV_ERR_NONE                Device interrupt(s)     successfully configured.
*                               NET_DEV_ERR_FAULT               Device interrupt(s) NOT successfully configured.
*
* Return(s)   : none.
*
* Caller(s)   : NetDev_Init().
*
* Note(s)     : none.
*********************************************************************************************************
*/

static  void  NetDev_CfgIntCtrl (NET_IF   *p_if,
                                 NET_ERR  *p_err)
{
    STM32F4xx_IF_Nbr = p_if->Nbr;                               /* Cfg this dev's BSP instance with specific IF #.      */

    BSP_IntVectSet(BSP_INT_ID_ETH, NetBSP_ISR_HandlerSTM32F4xx);
    BSP_IntEn(BSP_INT_ID_ETH);

   *p_err = NET_DEV_ERR_NONE;
}


/*
*********************************************************************************************************
*                                          NetDev_CfgGPIO()
*
* Description : Configure general-purpose I/O (GPIO) for the specified interface/device.
*
* Argument(s) : p_if        Pointer to network interface to configure.
*               ---         Argument validated in NetDev_Init().
*
*               p_err       Pointer to variable that will receive the return error code from this function :
*
*                               NET_DEV_ERR_NONE                Device GPIO     successfully configured.
*                               NET_DEV_ERR_FAULT               Device GPIO NOT successfully configured.
*
* Return(s)   : none.
*
* Caller(s)   : NetDev_Init().
*
* Note(s)     : none.
*********************************************************************************************************
*/

static  void  NetDev_CfgGPIO (NET_IF   *p_if,
                              NET_ERR  *p_err)
{
    NET_PHY_CFG_ETHER  *p_phy_cfg;
    GPIO_InitTypeDef    GPIO_InitStructure;


    p_phy_cfg = p_if->Ext_Cfg;                                  /* Obtain pointer to Phy cfg.                           */
    if (p_phy_cfg == (NET_PHY_CFG_ETHER *)0u) {
       *p_err = NET_DEV_ERR_INVALID_CFG;
        return;
    }

                                                                /* ------------------ PORT A PINS --------------------- */
    GPIO_InitStructure.Pin       = (GPIO_PIN_1 |                /* RX_CLK.                                              */
                                    GPIO_PIN_2 |                /* MDIO.                                                */
                                    GPIO_PIN_7);                /* RX_DV.                                               */
    GPIO_InitStructure.Speed     = GPIO_SPEED_HIGH;
    GPIO_InitStructure.Mode      = GPIO_MODE_AF_PP;
    GPIO_InitStructure.Pull      = GPIO_NOPULL;
    GPIO_InitStructure.Alternate = GPIO_AF11_ETH;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStructure);

                                                                /* ------------------ PORT B PINS --------------------- */
    GPIO_InitStructure.Pin       = (GPIO_PIN_5 |                /* PPS_OUT.                                             */
                                    GPIO_PIN_8);                /* MII_TXD3                                             */
    GPIO_InitStructure.Alternate = GPIO_AF11_ETH;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStructure);

                                                                /* ------------------ PORT C PINS --------------------- */
    GPIO_InitStructure.Pin       = (GPIO_PIN_1 |                /* MDC.                                                 */
                                    GPIO_PIN_2 |                /* MII_TXD2.                                            */
                                    GPIO_PIN_3 |                /* MII_TX_CLK.                                          */
                                    GPIO_PIN_4 |                /* RXD0.                                                */
                                    GPIO_PIN_5);                /* RXD1.                                                */
    GPIO_InitStructure.Alternate = GPIO_AF11_ETH;
    HAL_GPIO_Init(GPIOC, &GPIO_InitStructure);

                                                                /* ------------------ PORT G PINS --------------------- */
    GPIO_InitStructure.Pin       = (GPIO_PIN_11 |               /* TX_EN.                                               */
                                    GPIO_PIN_13 |               /* TXD0.                                                */
                                    GPIO_PIN_14);               /* TXD1.                                                */
    GPIO_InitStructure.Alternate = GPIO_AF11_ETH;
    HAL_GPIO_Init(GPIOG, &GPIO_InitStructure);

                                                                /* ------------------ PORT H PINS --------------------- */
    GPIO_InitStructure.Pin       = (GPIO_PIN_2 |                /* CRS.                                                 */
                                    GPIO_PIN_3 |                /* COL.                                                 */
                                    GPIO_PIN_6 |                /* RXD2.                                                */
                                    GPIO_PIN_7);                /* RXD3.                                                */
    GPIO_InitStructure.Alternate = GPIO_AF11_ETH;
    HAL_GPIO_Init(GPIOH, &GPIO_InitStructure);

                                                                /* ------------------ PORT I PINS --------------------- */
    GPIO_InitStructure.Pin       = GPIO_PIN_10;                 /* RX_ER.                                               */
    GPIO_InitStructure.Alternate = GPIO_AF11_ETH;
    HAL_GPIO_Init(GPIOI, &GPIO_InitStructure);

   *p_err = NET_DEV_ERR_NONE;
}


/*
*********************************************************************************************************
*                                         NetDev_ClkFreqGet()
*
* Description : Get device clock frequency.
*
* Argument(s) : p_if         Pointer to network interface to get clock frequency.
*               ----         Argument validated in NetIF_Add().
*
*               p_err        Pointer to variable that will receive the return error code from this function :
*
*                               NET_DEV_ERR_NONE                Device clock frequency     successfully
*                                                                   returned.
*                               NET_DEV_ERR_FAULT               Device clock frequency NOT successfully
*                                                                   returned.
*
* Return(s)   : Device clock frequency (in Hz).
*
* Caller(s)   : NetDev_Init().
*
* Note(s)     : none.
*********************************************************************************************************
*/

static  CPU_INT32U  NetDev_ClkFreqGet (NET_IF   *p_if,
                                       NET_ERR  *p_err)
{
    CPU_INT32U  clk_freq;


   (void)&p_if;                                                 /* Prevent 'variable unused' compiler warning.          */

    clk_freq = BSP_CPU_ClkFreq();                               /* HCLK is the MDC clk input freq.                      */
   *p_err    = NET_DEV_ERR_NONE;

    return (clk_freq);
}


/*
*********************************************************************************************************
*                                        NetBSP_ISR_HandlerSTM32F4xx()
*
* Description : BSP-level ISR handler(s) for device interrupts.
*
* Argument(s) : none.
*
* Return(s)   : none.
*
* Caller(s)   : CPU &/or device interrupts.
*
* Note(s)     : (1) (a) Each device interrupt, or set of device interrupts, MUST be handled by a
*                       unique BSP-level ISR handler which maps each specific device interrupt to
*                       its corresponding network interface ISR handler.
*
*                   (b) BSP-level device ISR handlers SHOULD be named using the following convention :
*
*                           NetDev_[Device]ISR_Handler[Type][Number]()
*
*                               where
*                                   (1) [Device]        Network device name or type (optional if the
*                                                           development board does NOT support multiple
*                                                           devices)
*                                   (2) [Type]          Network device interrupt type (optional if
*                                                           interrupt type is generic or unknown)
*                                   (3) [Number]        Network device number for each specific instance
*                                                           of device (optional if the development board
*                                                           does NOT support multiple instances of the
*                                                           specific device)
*
*                       See also 'NETWORK DEVICE BSP FUNCTION PROTOTYPES  Note #2a2'.
*********************************************************************************************************
*/

static  void  NetBSP_ISR_HandlerSTM32F4xx (void)
{
    NET_ERR  err;


    NetIF_ISR_Handler(STM32F4xx_IF_Nbr, NET_DEV_ISR_TYPE_UNKNOWN, &err);
}

#endif  /* NET_IF_ETHER_MODULE_EN */

