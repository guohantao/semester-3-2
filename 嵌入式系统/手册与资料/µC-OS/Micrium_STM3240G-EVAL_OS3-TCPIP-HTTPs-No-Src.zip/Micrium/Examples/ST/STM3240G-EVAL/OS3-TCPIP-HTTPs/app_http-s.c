/*
*********************************************************************************************************
*                                            EXAMPLE CODE
*
*               This file is provided as an example on how to use Micrium products.
*
*               Please feel free to use any application code labeled as 'EXAMPLE CODE' in
*               your application products.  Example code may be used as is, in whole or in
*               part, or may be used as a reference only. This file can be modified as
*               required to meet the end-product requirements.
*
*               Please help us continue to provide the Embedded community with the finest
*               software available.  Your honesty is greatly appreciated.
*
*               You can find our product's user manual, API reference, release notes and
*               more information at https://doc.micrium.com.
*               You can contact us at www.micrium.com.
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*
*                                              uC/HTTP-s
*                                           APPLICATION CODE
*
* Filename      : app_http-s.c
* Version       : V1.00
* Programmer(s) : FF
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*                                             INCLUDE FILES
*********************************************************************************************************
*/

#include <app_http-s.h>

/*
*********************************************************************************************************
*                                               ENABLE
*********************************************************************************************************
*/

#if (APP_CFG_HTTP_S_EN == DEF_ENABLED)

#include  <Server/FS/Static/static_files.h>
#include  <Server/Source/http-s.h>
#include  <http-s_instance_cfg.h>
#include  <Server/FS/Static/http-s_fs_static.h>


/*
*********************************************************************************************************
*                                            LOCAL DEFINES
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                       LOCAL GLOBAL VARIABLES
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                          FUNCTION PROTOTYPES
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                    LOCAL CONFIGURATION ERRORS
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*                                             AppHTTPs_Init
*
* Description : Initialize HTTP server.
*
* Arguments   : none.
*
* Returns     : none.
*
* Notes       : none.
*********************************************************************************************************
*/

CPU_BOOLEAN  AppHTTPs_Init (void)
{
    HTTPs_ERR        err_https;
    HTTPs_INSTANCE  *p_https_instance;

                                                                /* --------------- ADDING STATIC FILES ---------------- */
    HTTPs_FS_Init();

    HTTPs_FS_AddFile((CPU_CHAR *)&STATIC_INDEX_HTML_NAME[0u],
                     (void     *)&index_html[0u],
                     (CPU_INT32U) STATIC_INDEX_HTML_LEN);

    HTTPs_FS_AddFile((CPU_CHAR *)&STATIC_LOGO_GIF_NAME[0u],
                     (void     *)&logo_gif[0u],
                     (CPU_INT32U) STATIC_LOGO_GIF_LEN);

    HTTPs_FS_AddFile((CPU_CHAR *)&STATIC_404_HTML_NAME[0u],
                     (void     *)&not_found_html[0u],
                     (CPU_INT32U) STATIC_404_HTML_LEN);

                                                                /* -------------- INITIALIZE HTTP SERVER -------------- */
    APP_TRACE_INFO(("\n\r"));
    APP_TRACE_INFO(("Initialize HTTP server ...\n\r"));

    HTTPs_Init(DEF_NULL, &err_https);
    if (err_https != HTTPs_ERR_NONE) {
        APP_TRACE_INFO(("HTTP server: HTTPs_Init() failed\n\r"));
        return (DEF_FAIL);
    }

    if (err_https == HTTPs_ERR_NONE) {
        p_https_instance = HTTPs_InstanceInit(&HTTPs_CfgInstance,
                                              &HTTPs_TaskCfgInstance,
                                              &err_https);

        if (err_https != HTTPs_ERR_NONE) {
            APP_TRACE_INFO(("HTTP server: HTTPs_InstanceInit() failed\n\r"));
            return (DEF_FAIL);
        }

        HTTPs_InstanceStart(p_https_instance, &err_https);
    }

    if (err_https == HTTPs_ERR_NONE) {
        APP_TRACE_INFO(("HTTP server successfully initialized\n\r"));
        return (DEF_OK);
    } else {
        APP_TRACE_INFO(("HTTP server initialization failed\n\r"));
        return (DEF_FAIL);
    }
}

#endif
