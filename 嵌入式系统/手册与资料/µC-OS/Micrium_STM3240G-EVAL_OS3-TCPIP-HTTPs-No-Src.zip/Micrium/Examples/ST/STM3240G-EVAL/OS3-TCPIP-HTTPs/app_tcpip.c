/*
*********************************************************************************************************
*                                            EXAMPLE CODE
*
*               This file is provided as an example on how to use Micrium products.
*
*               Please feel free to use any application code labeled as 'EXAMPLE CODE' in
*               your application products.  Example code may be used as is, in whole or in
*               part, or may be used as a reference only. This file can be modified as
*               required to meet the end-product requirements.
*
*               Please help us continue to provide the Embedded community with the finest
*               software available.  Your honesty is greatly appreciated.
*
*               You can find our product's user manual, API reference, release notes and
*               more information at https://doc.micrium.com.
*               You can contact us at www.micrium.com.
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*
*                                   TCP/IP APPLICATION INITIALIZATION
*
*                                     ST Microelectronics STM32
*                                              on the
*
*                                           STM3240G-EVAL
*                                         Evaluation Board
*
* Filename      : app_tcpip.c
* Version       : V1.00
* Programmer(s) : DC
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                            INCLUDE FILES
*********************************************************************************************************
*/

#define    APP_TCPIP_MODULE
#include  <app_tcpip.h>
#include  <net_bsp.h>

/*
*********************************************************************************************************
*                                               ENABLE
*********************************************************************************************************
*/

#if (APP_CFG_TCPIP_EN == DEF_ENABLED)

/*
*********************************************************************************************************
*                                            LOCAL DEFINES
*********************************************************************************************************
*/

#define  APP_TCPIP_ADDR_LEN                     16u             /* Maximum Length of standard TCP/IP Address(s).        */


/*
*********************************************************************************************************
*                                             DATA TYPES
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                       LOCAL GLOBAL VARIABLES
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                            LOCAL MACRO'S
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                      LOCAL FUNCTION PROTOTYPES
*********************************************************************************************************
*/

void  AppTCPIP_PrintIPAddr (NET_IF_NBR  if_nbr);


/*
*********************************************************************************************************
*                                            AppTCPIP_Init()
*
* Description : Initialize uC/TCP-IP.
*
* Arguments   : perr    Pointer to variable to store NET_ERR return code.
*
* Return(s)   : none.
*
* Caller(s)   : Application.
*
* Note(s)     : none.
*********************************************************************************************************
*/

CPU_BOOLEAN  AppTCPIP_Init (void)
{
    NET_IF_NBR     if_nbr;
    NET_IPv4_ADDR  ip;
    NET_IPv4_ADDR  msk;
    NET_IPv4_ADDR  gateway;
    NET_ERR        net_err;

                                                                /* --------------------- INIT TCPIP ------------------- */
    APP_TRACE_INFO(("===================================================================\r\n"));
    APP_TRACE_INFO(("=                       TCPIP INITIALIZATION                      =\r\n"));
    APP_TRACE_INFO(("===================================================================\r\n"));
    APP_TRACE_INFO(("Initializing TCPIP...\r\n"));
    APP_TRACE_INFO(("\r\n"));

    net_err = Net_Init(&NetRxTaskCfg,                           /* Initialize uC/TCP-IP.                                */
                       &NetTxDeallocTaskCfg,
                       &NetTmrTaskCfg);
    if (net_err != NET_ERR_NONE) {
        APP_TRACE_INFO(("Net_Init() failed w/err = %d \r\n", net_err));
        return (DEF_FAIL);
    }
                                                                /* -------------- ETHERNET CONFIGURATION -------------- */
    if_nbr  = NetIF_Add((void *)&NetIF_API_Ether,               /* Ethernet  Interface API.                             */
                        (void *)&NetDev_API_GMAC,               /* STM3240G  Device API.                                */
                        (void *)&NetDev_BSP_STM32F4xx,          /* STM3240G  Device BSP.                                */
                        (void *)&NetDev_Cfg_STM32F407_0,        /* STM3240G  Device Configuration.                      */
                        (void *)&NetPhy_API_Generic,            /* Generic   Phy API.                                   */
                        (void *)&NetPhy_Cfg_STM32F407_0,        /* STM3240G  PHY Configuration.                         */
                                &net_err);
    if (net_err != NET_IF_ERR_NONE) {
        APP_TRACE_INFO(("NetIF_Add() failed w/err = %d \r\n", net_err));
        return (DEF_FAIL);
    }
                                                                /* ------------------ START IF NBR 1 ------------------ */
    NetIF_Start(if_nbr, &net_err);
    if (net_err != NET_IF_ERR_NONE) {
        APP_TRACE_INFO(("NetIF_Start() failed w/err = %d \r\n", net_err));
        return (DEF_FAIL);
    }

    NetIF_LinkStateWaitUntilUp(if_nbr, 20, 200, &net_err);
    if (net_err != NET_IF_ERR_NONE) {
        APP_TRACE_INFO(("NetIF_LinkStateWaitUntilUp() failed w/err = %d \r\n", net_err));
        return (DEF_FAIL);
    }

                                                                /* ------------------- CFG IF NBR 1 ------------------- */
    ip      = NetASCII_Str_to_IPv4((CPU_CHAR *)"10.10.1.238",   &net_err);
    msk     = NetASCII_Str_to_IPv4((CPU_CHAR *)"255.255.255.0", &net_err);
    gateway = NetASCII_Str_to_IPv4((CPU_CHAR *)"10.10.1.1",     &net_err);

    NetIPv4_CfgAddrAdd(if_nbr,
                       ip,
                       msk,
                       gateway,
                      &net_err);
    if (net_err != NET_IPv4_ERR_NONE) {
        APP_TRACE_INFO(("NetIPv4_CfgAddrAdd() failed w/err = %d \r\n", net_err));
        return (DEF_FAIL);
    }

    AppTCPIP_PrintIPAddr(if_nbr);                               /* Get & Display IP Address                             */

    return (DEF_OK);
}


/*
*********************************************************************************************************
*                                            AppTCPIP_Init()
*
* Description : Obtain and Display IP Address, Subnet Mask, and Default Gateway on TCPIP IF Connection.
*
* Arguments   : if_nbr      Interface Number to obtain interface information.
*
* Return(s)   : none.
*
* Caller(s)   : Application.
*
* Note(s)     : none.
*********************************************************************************************************
*/

void  AppTCPIP_PrintIPAddr (NET_IF_NBR  if_nbr)
{
    NET_IPv4_ADDR     ip_addr_tbl[NET_IPv4_CFG_IF_MAX_NBR_ADDR];
    NET_IPv4_ADDR     subnet_addr;
    NET_IPv4_ADDR     gateway_addr;
    NET_IP_ADDRS_QTY  ip_addr_tbl_qty;
    NET_ERR           net_err;
    CPU_CHAR          ip_disp_addr[APP_TCPIP_ADDR_LEN];
    CPU_CHAR          sub_disp_addr[APP_TCPIP_ADDR_LEN];
    CPU_CHAR          gate_disp_addr[APP_TCPIP_ADDR_LEN];


    Mem_Clr(ip_disp_addr,   sizeof(ip_disp_addr));              /* Init Var(s).                                         */
    Mem_Clr(sub_disp_addr,  sizeof(sub_disp_addr));
    Mem_Clr(gate_disp_addr, sizeof(gate_disp_addr));
    ip_addr_tbl_qty = sizeof(ip_addr_tbl) / sizeof(NET_IPv4_ADDR);

    NetIPv4_GetAddrHost(if_nbr,                                 /* Get IPv4 Host Addresses based on Interface Number.   */
                        &ip_addr_tbl[0u],
                        &ip_addr_tbl_qty,
                        &net_err);

    if (net_err != NET_IPv4_ERR_NONE) {
        APP_TRACE_INFO(("NetIPv4_GetAddrHost() failed w/err = %d \r\n", net_err));
        return;
    }
                                                                /* Get IPv4 Subnet Mask & Dflt Gateway from Host Addr   */
    subnet_addr  = NetIPv4_GetAddrSubnetMask (ip_addr_tbl[0u], &net_err);
    gateway_addr = NetIPv4_GetAddrDfltGateway(ip_addr_tbl[0u], &net_err);

    NetASCII_IPv4_to_Str( ip_addr_tbl[0u],                      /* Set IPv4 IP Address to string.                       */
                         &ip_disp_addr[0u],
                          DEF_NO,
                         &net_err);

    NetASCII_IPv4_to_Str( subnet_addr,                          /* Set IPv4 Subnet Mask to String.                      */
                         &sub_disp_addr[0u],
                          DEF_NO,
                         &net_err);

    NetASCII_IPv4_to_Str( gateway_addr,                         /* Set IPv4 Default Gateway to String.                  */
                         &gate_disp_addr[0u],
                          DEF_NO,
                         &net_err);

                                                                /* -------------------- DISPLAY ADDR ------------------ */
    APP_TRACE_INFO(("- ETHERNET CONFIGURATION - \r\n"));
    APP_TRACE_INFO(("IP Address      : %s \r\n", ip_disp_addr  ));
    APP_TRACE_INFO(("Subnet Mask     : %s \r\n", sub_disp_addr ));
    APP_TRACE_INFO(("Default Gateway : %s \r\n", gate_disp_addr));
    APP_TRACE_INFO(("\r\n"));
}


/*
*********************************************************************************************************
*                                             ENABLE END
*********************************************************************************************************
*/

#endif
